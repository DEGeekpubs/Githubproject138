import "./style.css";
export default function Hero() {
  return (
    <section className="hero width100 flex alignCenter justifyCenter">
      <div className="heroContainer flex alignCenter justifyCenter width95 maxWidth">
        Hero
      </div>
    </section>
  );
}
