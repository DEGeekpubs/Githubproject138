export default function ReturnPolicy() {
  return <main>Return Policy</main>;
}
