export default function PrivacyPolicy() {
  return <main>Privacy Policy</main>;
}
