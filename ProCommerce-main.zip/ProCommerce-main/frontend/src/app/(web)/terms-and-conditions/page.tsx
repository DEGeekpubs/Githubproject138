export default function TermsAndConditions() {
  return <main>Terms And Conditions</main>;
}
