import PageLoader from "@/components/local/loaders/pageLoader/PageLoader";

export default function Loading() {
  return <PageLoader />;
}
