export default function ForgetPassword() {
  return <main>Forget Password</main>;
}
