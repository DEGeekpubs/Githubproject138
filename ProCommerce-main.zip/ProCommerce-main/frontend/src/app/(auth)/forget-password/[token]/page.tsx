export default function ResetPassword() {
  return <main>Reset Password</main>;
}
