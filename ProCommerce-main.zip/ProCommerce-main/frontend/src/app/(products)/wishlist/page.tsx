import "./style.css";
export default function Wishlist() {
  return <>Page</>;
}
