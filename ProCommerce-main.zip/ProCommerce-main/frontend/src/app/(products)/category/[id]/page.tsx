export default function Category() {
  return <main>Category</main>;
}
