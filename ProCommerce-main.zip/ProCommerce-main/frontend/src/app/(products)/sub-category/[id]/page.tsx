export default function SubCategory() {
  return <main>Sub Category</main>;
}
