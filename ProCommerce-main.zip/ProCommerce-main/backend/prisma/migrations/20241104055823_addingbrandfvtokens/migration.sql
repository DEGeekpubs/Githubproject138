-- AlterTable
ALTER TABLE "Brand" ADD COLUMN     "forgetPasswordToken" TEXT,
ADD COLUMN     "verificationToken" TEXT;
